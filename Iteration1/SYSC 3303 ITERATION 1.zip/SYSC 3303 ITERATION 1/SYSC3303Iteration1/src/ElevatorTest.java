public class ElevatorTest {

    public static void main(String[] args) {
        testElevatorInitialization();
        testUpdateCurrentFloor();
        // Add more test methods as needed
    }

    private static void testElevatorInitialization() {
        Scheduler scheduler = new Scheduler();
        Elevator elevator = new Elevator(scheduler);

        System.out.println("Testing elevator initialization");

        if (elevator.getCurrentFloor() == 1 && elevator.getTargetFloor() == 1) {
            System.out.println("Elevator initialized successfully");
        } else {
            System.out.println("Elevator not initialized successfully");
        }
    }

    private static void testUpdateCurrentFloor() {
        Scheduler scheduler = new Scheduler();
        Elevator elevator = new Elevator(scheduler);

        System.out.println("Testing update current floor");

        elevator.updateCurrentFloor(5);

        // Assuming getCurrentFloor returns the current floor
        if (elevator.getCurrentFloor() == 5) {
            System.out.println("Current floor updated successfully");
        } else {
            System.out.println("Current floor failed to update successfully");
        }
    }
}